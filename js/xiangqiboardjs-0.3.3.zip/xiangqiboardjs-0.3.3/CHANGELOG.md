# xiangqiboard.js Change Log

All notable changes to this project will be documented in this file.

## [0.3.0] - 2020-04-14

- Adapted to ES6

## [0.2.0] - 2019-04-14

- Removed unnecessary square color
- xiangqi.js integration examples

## [0.1.0] - 2018-08-22

- Initial release
